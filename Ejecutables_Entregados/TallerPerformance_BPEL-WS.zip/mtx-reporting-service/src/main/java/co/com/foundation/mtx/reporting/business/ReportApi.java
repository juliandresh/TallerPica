package co.com.foundation.mtx.reporting.business;

import java.util.List;
import java.util.Optional;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import co.com.foundation.mtx.reporting.model.MaintenanceExecution;
import co.com.foundation.mtx.reporting.model.Operator;
import co.com.foundation.mtx.reporting.model.ReportDTO;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class ReportApi {
	@PersistenceContext(unitName = "reporting-pu")
	private EntityManager entityManager;

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public ReportDTO generate() {
		ReportDTO reportDTO = new ReportDTO();
		//String query = "select me from MaintenanceExecution me";
		//Obtiene información de la tabla clase MaintenanceExecution
		List<MaintenanceExecution> list = entityManager.createNamedQuery("MaintenanceExecution.findAll", MaintenanceExecution.class).getResultList();		
		list.forEach((me) -> {
			evaluateOperators_Cost(reportDTO, me.getOperatorList());
			reportDTO.addMaintenanceCount();
		});		
		return reportDTO;
	}
	
	private void evaluateOperators_Cost(ReportDTO reportDTO, List<Operator> operators) {
		operators.forEach((o) -> {		
			Optional<Operator> optional = Optional.ofNullable(o);
			//Si el objeto no es nulo
			if (optional.isPresent()) {
					Operator operator = entityManager.createNamedQuery("Operator.findById", Operator.class)
						.setParameter("ID", o.getId())
						.getSingleResult();
				
				if( !reportDTO.getOperators().contains( operator.getFullName() ) ){
					reportDTO.getOperators().add( operator.getFullName() );			
				}
				reportDTO.addCost(operator.getCharge());
			}
		});
	}
}
